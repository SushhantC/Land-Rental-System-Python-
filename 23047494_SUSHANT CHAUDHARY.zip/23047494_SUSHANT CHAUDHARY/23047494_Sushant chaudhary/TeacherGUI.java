import javax.swing.*; // component
import java.awt.*; // design
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.ArrayList;

public class TeacherGUI {

    ArrayList<Teacher> Teacherl = new ArrayList<>();

    public void Gui()
    {
        JFrame frame = new JFrame("Teacher GUI");
        frame.setVisible(true);
        // Set the background color
        frame.getContentPane().setBackground(Color.GRAY);
        frame.setSize(1800, 1800); //(length,breadth)
        frame.setLayout(null);

        //adding teacher
        JLabel l101 = new JLabel("TEACHER GUI");
        l101.setBounds(700, 2, 200, 50);//x-axis,y-axis,length,height
        l101.setFont(new Font("TimeOFRoman", Font.BOLD, 25));
        l101.setForeground(Color.WHITE); // Set text color to white
        frame.add(l101);

        // Panel 1: Teacher Information
        JPanel teacherPanel = new JPanel();
        teacherPanel.setLayout(null);
        Color backgroundColor2 = new Color(178, 171, 169); // Red color
        teacherPanel.setBackground(backgroundColor2);
        teacherPanel.setBounds(160, 40, 1200, 900);
        teacherPanel.setBorder(BorderFactory.createTitledBorder(""));
        frame.add(teacherPanel);

        JLabel t1 = new JLabel("TEACHER");
        t1.setBounds(70, 100, 200, 50);//x-axis,y-axis,length,height
        t1.setFont(new Font("TimeOFRoman", Font.BOLD, 24));
        teacherPanel.add(t1);

        JLabel t11 = new JLabel("Teacher id:");
        t11.setBounds(65, 140, 120, 50);
        teacherPanel.add(t11);

        JTextField f1 = new JTextField();
        f1.setBounds(200, 155, 120, 20);
        teacherPanel.add(f1);

        JLabel t12 = new JLabel("Teacher Name:");
        t12.setBounds(65, 182, 120, 50);
        teacherPanel.add(t12);

        JTextField f12 = new JTextField();
        f12.setBounds(200, 200, 120, 20);
        teacherPanel.add(f12);

        JLabel t13 = new JLabel("Address:");
        t13.setBounds(65, 224, 120, 50);
        teacherPanel.add(t13);

        JTextField f13 = new JTextField();
        f13.setBounds(200, 242, 120, 20);
        teacherPanel.add(f13);

        JLabel t14 = new JLabel("Working Type:");
        t14.setBounds(65, 266, 120, 50);
        teacherPanel.add(t14);

        JTextField f14 = new JTextField();
        f14.setBounds(200, 287, 120, 20);
        teacherPanel.add(f14);

        JLabel t15 = new JLabel("Employment status:");
        t15.setBounds(65, 308, 120, 50);
        teacherPanel.add(t15);

        JTextField f15 = new JTextField();
        f15.setBounds(200, 330, 120, 20);
        teacherPanel.add(f15);

        JButton b1 = new JButton("Clear");
        b1.setBounds(180, 375, 90, 30);//x-axis,y-axis,length,height
        b1.setBackground(Color.YELLOW);
        teacherPanel.add(b1);

        JButton b2 = new JButton("Display");
        b2.setBounds(280, 375, 90, 30);//x-axis,y-axis,length,height
        b2.setBackground(Color.YELLOW);
        teacherPanel.add(b2);

        //adding lecturer

        JLabel l1 = new JLabel("LECTURER");
        l1.setBounds(510, 100, 200, 50);//x-axis,y-axis,length,height
        l1.setFont(new Font("TimeOFRoman", Font.BOLD, 24));
        teacherPanel.add(l1);

        JLabel l11 = new JLabel("Department:");
        l11.setBounds(450, 140, 120, 50);
        teacherPanel.add(l11);

        JTextField f21 = new JTextField();
        f21.setBounds(580, 158, 120, 20);
        teacherPanel.add(f21);

        JLabel l12 = new JLabel("Year oF experience:");
        l12.setBounds(450, 182, 120, 50);
        teacherPanel.add(l12);

        JTextField f22 = new JTextField();
        f22.setBounds(580, 200, 120, 20);
        teacherPanel.add(f22);

        JLabel l13 = new JLabel("Working Hours:");
        l13.setBounds(450, 222, 120, 50);
        teacherPanel.add(l13);

        JTextField f23 = new JTextField();
        f23.setBounds(580, 244, 120, 20);
        teacherPanel.add(f23);

        JButton b3 = new JButton("Add Lecturer");
        b3.setBounds(580, 375, 120, 30);//x-axis,y-axis,length,height
        b3.setBackground(Color.YELLOW);
        teacherPanel.add(b3);
        //end adding lecturer

        //Adding Tutor
        JLabel tt1 = new JLabel(" TUTOR");
        tt1.setBounds(950, 100, 200, 50);//x-axis,y-axis,length,height
        tt1.setFont(new Font("TimeOFRoman", Font.BOLD, 24));
        teacherPanel.add(tt1);

        JLabel tt11 = new JLabel("Salary:");
        tt11.setBounds(800, 140, 120, 50);
        teacherPanel.add(tt11);

        JTextField tt21 = new JTextField();
        tt21.setBounds(960, 158, 120, 20);
        teacherPanel.add(tt21);

        JLabel tt12 = new JLabel("Performance Index:");
        tt12.setBounds(800, 183, 120, 50);
        teacherPanel.add(tt12);

        JTextField tt22 = new JTextField();
        tt22.setBounds(960, 203, 120, 20);
        teacherPanel.add(tt22);

        JLabel tt13 = new JLabel("Specialization:");
        tt13.setBounds(800, 226, 120, 50);
        teacherPanel.add(tt13);

        JTextField tt23 = new JTextField();
        tt23.setBounds(960, 246, 120, 20);
        teacherPanel.add(tt23);

        JLabel tt14 = new JLabel("Academic Qualification:");
        tt14.setBounds(800, 270, 150, 50);
        teacherPanel.add(tt14);

        JTextField tt24 = new JTextField();
        tt24.setBounds(960, 289, 120, 20);
        teacherPanel.add(tt24);

        JLabel tt15 = new JLabel("Working Hours:");
        tt15.setBounds(800, 310, 120, 50);
        teacherPanel.add(tt15);

        JTextField f16 = new JTextField();
        f16.setBounds(960, 325, 120, 20);
        teacherPanel.add(f16);

        JButton b4 = new JButton("Add Tutor");
        b4.setBounds(960, 370, 120, 30);//x-axis,y-axis,length,height
        b4.setBackground(Color.YELLOW);
        teacherPanel.add(b4);
        //tutor end//

        //setting salary//
        JLabel s1 = new JLabel(" Salary");
        s1.setBounds(100, 500, 200, 50);//x-axis,y-axis,length,height
        s1.setFont(new Font("TimeOFRoman", Font.BOLD, 24));
        teacherPanel.add(s1);

        JLabel s11 = new JLabel("Teacher id:");
        s11.setBounds(65, 542, 120, 50);
        teacherPanel.add(s11);

        JTextField s21 = new JTextField();
        s21.setBounds(200, 558, 120, 20);
        teacherPanel.add(s21);

        JLabel s12 = new JLabel("New Salary:");
        s12.setBounds(65, 584, 120, 50);
        teacherPanel.add(s12);

        JTextField s22 = new JTextField();
        s22.setBounds(200, 600, 120, 20);
        teacherPanel.add(s22);

        JLabel s13 = new JLabel("New Performance Index:");
        s13.setBounds(65, 627, 150, 50);
        teacherPanel.add(s13);

        JTextField s23 = new JTextField();
        s23.setBounds(200, 645, 120, 20);
        teacherPanel.add(s23);

        JButton b5 = new JButton("Set salary");
        b5.setBounds(65, 725, 120, 30);//x-axis,y-axis,length,height
        b5.setBackground(Color.YELLOW);
        teacherPanel.add(b5);

        //grading assignment

        JLabel a1 = new JLabel("Grading Assignment");
        a1.setBounds(510, 500, 400, 50);//x-axis,y-axis,length,height
        a1.setFont(new Font("TimeOFRoman", Font.BOLD, 24));
        teacherPanel.add(a1);

        JLabel a11 = new JLabel("Teacher id :");
        a11.setBounds(450, 540, 120, 50);
        teacherPanel.add(a11);

        JTextField a21 = new JTextField();
        a21.setBounds(580, 555, 120, 20);
        teacherPanel.add(a21);

        JLabel a12 = new JLabel("Department :");
        a12.setBounds(450, 580, 120, 50);
        teacherPanel.add(a12);

        JTextField a22 = new JTextField();
        a22.setBounds(580, 595, 120, 20);
        teacherPanel.add(a22);

        JLabel a13 = new JLabel("Years oF experience:");
        a13.setBounds(450, 620, 150, 50);
        teacherPanel.add(a13);

        JTextField a23 = new JTextField();
        a23.setBounds(580, 636, 120, 20);
        teacherPanel.add(a23);

        JLabel a14 = new JLabel("Graded Score:");
        a14.setBounds(450, 660, 150, 50);
        teacherPanel.add(a14);

        JTextField a24 = new JTextField();
        a24.setBounds(580, 676, 120, 20);
        teacherPanel.add(a24);

        JButton b6 = new JButton("Grade Assignments");
        b6.setBounds(580, 716, 170, 30);//x-axis,y-axis,length,height
        b6.setBackground(Color.YELLOW);
        teacherPanel.add(b6);

        //grade assignment end

        //removing tutor
        JLabel RT1 = new JLabel("Removing Tutor");
        RT1.setBounds(945, 500, 200, 50);//x-axis,y-axis,length,height
        RT1.setFont(new Font("TimeOFRoman", Font.BOLD, 24));
        teacherPanel.add(RT1);

        JLabel RT11 = new JLabel("Teacher Id:");
        RT11.setBounds(850, 540, 120, 50);
        teacherPanel.add(RT11);

        JTextField RT21 = new JTextField();
        RT21.setBounds(960, 555, 120, 20);
        teacherPanel.add(RT21);

        JButton b7 = new JButton("Remove Tutor");
        b7.setBounds(850, 600, 120, 30);//x-axis,y-axis,length,height
        b7.setBackground(Color.YELLOW);
        teacherPanel.add(b7);
        //tutor end// */

        //                                                                                         clear button start

        b1.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent ae) {
                    f1.setText("");
                    f12.setText("");
                    f13.setText("");
                    f14.setText("");
                    f15.setText("");
                    f16.setText("");
                    f21.setText("");
                    f22.setText("");
                    f23.setText("");
                    tt21.setText("");
                    tt22.setText("");
                    tt23.setText("");
                    tt24.setText("");
                    s21.setText("");
                    s22.setText("");
                    s23.setText("");
                    a21.setText("");
                    a22.setText("");
                    a23.setText("");
                    a24.setText("");
                    RT21.setText("");
                }
            });
        //                                                                           clear button end//

        //                                                                                 display                                                             
        b2.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent ae) {
                    // Check if any of the text fields are empty
                    if (f1.getText().isEmpty()) {
                        JOptionPane.showMessageDialog(null, "Please fill in all the required fields.");
                        return; // Exit the method if any field is empty
                    }

                    try {
                        // Retrieve input value of teacher ID
                        int teacherId = Integer.parseInt(f1.getText());

                        // Search for the teacher with the given ID
                        for (Teacher teacher : Teacherl) {
                            if (teacher.getTeacherId() == teacherId) {
                                // Display information related to the appropriate class based on the instance type
                                if (teacher instanceof Tutor) {
                                    // If the teacher is a Tutor, display Tutor information
                                    Tutor tutor = (Tutor) teacher; // Casting Teacher object to Tutor

                                    // Display Tutor information using JOptionPane or any other suitable method
                                    JOptionPane.showMessageDialog(null, "Tutor Information\n\n" +
                                        "Teacher ID: " + tutor.getTeacherId() + "\n" +
                                        "Teacher Name: " + tutor.getTeacherName() + "\n" +
                                        "Address: " + tutor.getAddress() + "\n" +
                                        "Working Type: " + tutor.getWorkingType() + "\n" +
                                        "Employment Status: " + tutor.getEmploymentStatus() + "\n" +
                                        "Working Hours: " + tutor.getWorkingHours() + "\n" +
                                        "Salary: " + tutor.getSalary() + "\n" +
                                        "Specialization: " + tutor.getSpecialization() + "\n" +
                                        "Academic Qualifications: " + tutor.getAcademicQualifications() + "\n" +
                                        "Performance Index: " + tutor.getPerformanceIndex());
                                    // Print tutor information to BlueJ's terminal
                                    tutor.display();
                                } else if (teacher instanceof Lecturer) {
                                    // If the teacher is a Lecturer, display Lecturer information
                                    Lecturer lecturer = (Lecturer) teacher; // Casting Teacher object to Lecturer
                                    // Display Lecturer information using JOptionPane or any other suitable method
                                    JOptionPane.showMessageDialog(null, "Lecturer Information\n\n" +
                                        "Teacher ID: " + lecturer.getTeacherId() + "\n" +
                                        "Teacher Name: " + lecturer.getTeacherName() + "\n" +
                                        "Address: " + lecturer.getAddress() + "\n" +
                                        "Department: " + lecturer.getDepartment() + "\n" +
                                        "Years of Experience: " + lecturer.getYearsOfExperience() + "\n" +
                                        "Graded Score: " + lecturer.getGradedScore() + "\n" +
                                        "Working Hours: " + lecturer.getWorkingHours());
                                    // Print Lecturer information to BlueJ's terminal
                                    lecturer.display();
                                }

                                return; // Exit the loop after finding the teacher
                            }
                        }

                        // If no teacher with the given ID is found
                        JOptionPane.showMessageDialog(null, "No teacher found with ID: " + teacherId);
                    } catch (NumberFormatException e) {
                        JOptionPane.showMessageDialog(null, "Invalid input format. Please enter a valid number for teacher ID.");
                    }
                }
            });

        //                                                                                         display end 

        //                                                                                     add lecturer                                                                                      //
        b3.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent ae) {
                    // Check if any of the text fields are empty
                    if (f1.getText().isEmpty() || f21.getText().isEmpty() || f22.getText().isEmpty() || f23.getText().isEmpty()) {
                        JOptionPane.showMessageDialog(null, "Please fill in the required fields.");
                        return; // Exit the method if any field is empty
                    }

                    try {
                        // Retrieve input values from text fields
                        int teacherId = Integer.parseInt(f1.getText());
                        String teacherName = f12.getText();
                        String address = f13.getText();
                        String workingType = f14.getText();
                        String employmentStatus = f15.getText();
                        String department = f21.getText();
                        int yearsOfExperience = Integer.parseInt(f22.getText());
                        int workingHours = Integer.parseInt(f23.getText());

                        // Create a new Lecturer object
                        Lecturer newLecturer = new Lecturer(teacherId, teacherName, address, workingType, employmentStatus, department, yearsOfExperience,workingHours );

                        // Add the new Lecturer object to the ArrayList
                        Teacherl.add(newLecturer);

                        JOptionPane.showMessageDialog(null, "Lecturer added successfully with ID: " + teacherId);

                    } catch (NumberFormatException e) {
                        JOptionPane.showMessageDialog(null, "Invalid input format. Please enter valid numbers for ID, years of experience, and Working Hours.");
                    }
                }
            });

        //                                                                                          add leturer 

        //                                                                                   add  tutor start  
        b4.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent ae) {
                    // Check if any of the text fields are empty
                    if ( f1.getText().isEmpty() || f16.getText().isEmpty() ||
                    tt21.getText().isEmpty() || tt22.getText().isEmpty() || tt23.getText().isEmpty() ||
                    tt24.getText().isEmpty()) {
                        JOptionPane.showMessageDialog(null, "Please fill in all the required fields.");
                        return; // Exit the method if any field is empty
                    }

                    try {
                        // Retrieve input values from text fields
                        int teacherId = Integer.parseInt(f1.getText());
                        String teacherName = f12.getText();
                        String address = f13.getText();
                        String workingType = f14.getText();
                        String employmentStatus = f15.getText();
                        int workingHours = Integer.parseInt(f16.getText()); // Assuming there's a text field for working hours
                        double salary = Double.parseDouble(tt21.getText());
                        String specialization = tt23.getText();
                        String academicQualifications = tt24.getText();
                        int performanceIndex = Integer.parseInt(tt22.getText());

                        // Create a new Tutor object
                        Tutor newTutor = new Tutor(teacherId, teacherName, address, workingType, employmentStatus,
                                workingHours, salary, specialization, academicQualifications, performanceIndex);

                        // Add the new Tutor object to the ArrayList
                        Teacherl.add(newTutor);

                        JOptionPane.showMessageDialog(null, "Tutor added successfully with ID: " + teacherId);
                    } catch (NumberFormatException e) {
                        JOptionPane.showMessageDialog(null, "Invalid input format. Please enter valid numbers for ID, working hours, salary, and performance index.");
                    }
                }
            });
        //                                                                                          add  tutor end 

        //                                                                    Add ActionListener for setting the salary of a Tutor

        b5.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent ae) {
                    // Check if any of the text fields are empty
                    if (
                    s21.getText().isEmpty() || s22.getText().isEmpty() || s23.getText().isEmpty()) {
                        JOptionPane.showMessageDialog(null, "Please fill in all the required fields.");
                        return; // Exit the method if any field is empty
                    }

                    try {
                        // Retrieve input values from text fields
                        int teacherId = Integer.parseInt(s21.getText());
                        double newSalary = Double.parseDouble(s22.getText());
                        int newPerformanceIndex = Integer.parseInt(s23.getText());

                        // Search for the Tutor with the given ID
                        for (Teacher teacher : Teacherl) {
                            if (teacher instanceof Tutor && teacher.getTeacherId() == teacherId) {
                                // Downcast Teacher object to Tutor
                                Tutor tutor = (Tutor) teacher;

                                // Set the new salary and performance index
                                tutor.setSalary(newSalary, newPerformanceIndex);

                                // Display a message dialog confirming the successful update
                                JOptionPane.showMessageDialog(null, "Salary set successfully for Tutor with ID: " + teacherId);
                                // Print updated Tutor information to BlueJ's terminal

                                return; // Exit the loop after setting the salary
                            }
                        }

                        // If no Tutor with the given ID is found
                        JOptionPane.showMessageDialog(null, "No Tutor found with ID: " + teacherId);
                    } catch (NumberFormatException e) {
                        JOptionPane.showMessageDialog(null, "Invalid input format. Please enter valid numbers for teacher ID, new salary, and new performance index.");
                    }
                }
            });

        //                                                                           end of setting the salary of a Tutor

        //                                                                         Add ActionListener for grading assignments                                                           //
        b6.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent ae) {
                    // Check if any of the text fields are empty
                    if (
                    a21.getText().isEmpty() || a22.getText().isEmpty() || a23.getText().isEmpty() ||
                    a24.getText().isEmpty()) {
                        JOptionPane.showMessageDialog(null, "Please fill in all the required fields.");
                        return; // Exit the method if any field is empty
                    }

                    try {
                        // Retrieve input values from text fields
                        int teacherId = Integer.parseInt(a21.getText());
                        int gradedScore = Integer.parseInt(a24.getText());
                        String department = a22.getText();
                        int yearsOfExperience = Integer.parseInt(a23.getText());

                        // Display entered information
                        JOptionPane.showMessageDialog(null, "Grading Assignment Information\n\n" +
                            "Teacher ID: " + teacherId + "\n" +
                            "Graded Score: " + gradedScore + "\n" +
                            "Department: " + department + "\n" +
                            "Years of Experience: " + yearsOfExperience);

                        // Search for the Lecturer with the given ID
                        for (Teacher teacher : Teacherl) {
                            if (teacher instanceof Lecturer && teacher.getTeacherId() == teacherId) {
                                // Downcast Teacher object to Lecturer
                                Lecturer lecturer = (Lecturer) teacher;

                                // Call the method to grade assignments for the Lecturer
                                lecturer.gradeAssignment(gradedScore, department, yearsOfExperience);
                                lecturer.display();

                                // Display a message dialog confirming the successful grading of assignments
                                JOptionPane.showMessageDialog(null, "Assignments graded successfully for Lecturer with ID: " + teacherId);

                                return; // Exit the loop after grading the assignments
                            }
                        }

                        // If no Lecturer with the given ID is found
                        JOptionPane.showMessageDialog(null, "No Lecturer found with ID: " + teacherId);
                    } catch (NumberFormatException e) {
                        JOptionPane.showMessageDialog(null, "Invalid input format. Please enter valid numbers for teacher ID, graded score, and years of experience.");
                    }
                }
            });

        //                                                                                        end gradeassignments                            

        //                                                                                           Remove the tutor//
        b7.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent ae) {
                    // Check if any of the text fields are empty
                    if (
                    RT21.getText().isEmpty()) {
                        JOptionPane.showMessageDialog(null, "Please fill the Teacherid to remove tutor in required fields.");
                        return; // Exit the method if any field is empty
                    }

                    try {
                        // Retrieve input value of teacher ID
                        int teacherIdToRemove = Integer.parseInt(RT21.getText());

                        // Search for the Tutor with the given ID
                        for (Teacher teacher : Teacherl) {
                            if (teacher instanceof Tutor && teacher.getTeacherId() == teacherIdToRemove) {
                                // If the teacher is a Tutor and has the given ID, remove it from the list
                                Tutor tutorToRemove = (Tutor) teacher; // Casting Teacher object to Tutor
                                Teacherl.remove(tutorToRemove);

                                // Show a dialog confirming the removal of the Tutor
                                JOptionPane.showMessageDialog(null, "Tutor with ID " + teacherIdToRemove + " has been removed successfully.");

                                return; // Exit the loop after removing the tutor
                            }
                        }

                        // If no Tutor with the given ID is found
                        JOptionPane.showMessageDialog(null, "No Tutor found with ID: " + teacherIdToRemove);
                    } catch (NumberFormatException e) {
                        JOptionPane.showMessageDialog(null, "Invalid input format. Please enter a valid number for teacher ID to remove.");
                    }
                }
            });

        //                                                                                         Remove the tutor end     

    }

    public static void main(String[] args) {
        // Create an instance of TeacherGUI
        TeacherGUI teacherGUI = new TeacherGUI();

        // Call the gui() method
        teacherGUI.Gui();
    }

}

