
// Define a class named Lecturer, extending the Teacher class
public class Lecturer extends Teacher {

    // Private instance variables specific to the Lecturer class
    private String department;
    private int yearsOfExperience;
    private int gradedScore;
    private boolean hasGraded;

    // Constructor to initialize a Lecturer object with basic information
    public Lecturer(int teacherId, String teacherName, String address, String workingType,
                    String employmentStatus, String department, int yearsOfExperience, int workingHours) {
        // Call the constructor of the superclass (Teacher) to initialize common attributes
        super(teacherId, teacherName, address, workingType, employmentStatus);

        // Initialize additional attributes specific to the Lecturer class
        this.department = department;
        this.yearsOfExperience = yearsOfExperience;
        this.gradedScore = 0;
        this.hasGraded = false;

        // Set the working hours using the provided value
        super.setWorkingHours(workingHours);
    }

    // Accessor method for department
    public String getDepartment() {
        return department;
    }

    // Accessor method for yearsOfExperience
    public int getYearsOfExperience() {
        return yearsOfExperience;
    }

    // Accessor method for gradedScore
    public int getGradedScore() {
        return gradedScore;
    }

    // Accessor method for hasGraded
    public boolean hasGraded() {
        return hasGraded;
    }

    // Method to set the graded score for a lecturer
    public void setGradedScore(int newScore) {
        this.gradedScore = newScore;
    }

    // Override the setWorkingHours method from the superclass (Teacher)
    @Override
    public void setWorkingHours(int newWorkingHours) {
        // Set the working hours for the lecturer
        super.setWorkingHours(newWorkingHours);
    }

    // Method to grade an assignment based on certain conditions
    public void gradeAssignment(int gradedScore, String department, int yearsOfExperience) {
        // Check if the lecturer meets the criteria for grading assignments
        if (yearsOfExperience >= 5 && this.department.equals(department)) {
            // Determine the graded score based on specific conditions
            if (gradedScore >= 70) { 
                this.gradedScore = gradedScore;
                System.out.println("you achieved grade A");
            } else if (gradedScore >= 60) {
                this.gradedScore = 60;
                 System.out.println("you achieved grade B");
            } else if (gradedScore >= 50) {
                this.gradedScore = 50;
                 System.out.println("you achieved grade C");
            } else if (gradedScore >= 40) {
                this.gradedScore = 40;
                 System.out.println("you achieved grade D");
            } else {
                this.gradedScore = gradedScore;
            }
            this.hasGraded = true; // Set the flag indicating that the lecturer has graded an assignment
        } else {
            System.out.println("Lecturer cannot grade assignments yet.");
        }
    }

    // Method to display the information of a lecturer
    @Override
    public void display() {
        // Call the display method of the superclass (Teacher) to display common information
        super.display();
        
        // Display additional information specific to the Lecturer class
        System.out.println("Department: " + department);
        System.out.println("Years of Experience: " + yearsOfExperience);
        
        // Display the graded score or a message indicating it hasn't been graded yet
        if (hasGraded) {
            System.out.println("Graded Score: " + gradedScore);
        } else {
            System.out.println("Graded Score: Not graded yet");
        }
        
    }
}