// Define a class named Teacher
public class Teacher {
    // Private instance variables to store teacher information
    private int teacherId;
    private String teacherName;
    private String address;
    private String workingType;
    private String employmentStatus;
    private int workingHours; 

    // Constructor to initialize the Teacher object with basic information
    public Teacher(int teacherId, String teacherName, String address, String workingType, String employmentStatus) {
        this.teacherId = teacherId;
        this.teacherName = teacherName;
        this.address = address;
        this.workingType = workingType;
        this.employmentStatus = employmentStatus;
        this.workingHours = -1; // Initialize working hours to -1 as a default value
    }

    // Accessor method for teacherId
    public int getTeacherId() {
        return teacherId;
    }

    // Accessor method for teacherName
    public String getTeacherName() {
        return teacherName;
    }

    // Accessor method for address
    public String getAddress() {
        return address;
    }

    // Accessor method for workingType
    public String getWorkingType() {
        return workingType;
    }

    // Accessor method for employmentStatus
    public String getEmploymentStatus() {
        return employmentStatus;
    }

    // Accessor method for workingHours
    public int getWorkingHours() {
        return workingHours;
    }

    // Method to set the working hours for the teacher
    public void setWorkingHours(int newWorkingHours) {
        this.workingHours = newWorkingHours;
    }

    // Method to display the teacher's information
    public void display() {
        // Display the teacher's ID
        System.out.println("Teacher ID: " + getTeacherId());
        // Display the teacher's name
        System.out.println("Teacher Name: " + getTeacherName());
        // Display the teacher's address
        System.out.println("Address: " + getAddress());
        // Display the type of work the teacher is engaged in
        System.out.println("Working Type: " + getWorkingType());
        // Display the employment status of the teacher
        System.out.println("Employment Status: " + getEmploymentStatus());
        
        // Check if working hours are assigned and display accordingly
        if (getWorkingHours() != -1) {
            System.out.println("Working Hours: " + getWorkingHours());
        } else {
            System.out.println("Working Hours: Not assigned");
        }
    }
}
