// Define a class named Tutor, extending the Teacher class
public class Tutor extends Teacher {

    // Private instance variables specific to the Tutor class
    
    private double salary;
    private String specialization;
    private String academicQualifications;
    private int performanceIndex;
    private boolean isCertified;

    // Constructor to initialize a Tutor object with basic information
    public Tutor(int teacherId, String teacherName, String address, String workingType, String employmentStatus,
                 int workingHours, double salary, String specialization, String academicQualifications, int performanceIndex) {
        // Call the constructor of the superclass (Teacher) to initialize common attributes
        super(teacherId, teacherName, address, workingType, employmentStatus);
        super.setWorkingHours(workingHours);
        // Initialize additional attributes specific to the Tutor class
        
        this.salary = salary;
        this.specialization = specialization;
        this.academicQualifications = academicQualifications;
        this.performanceIndex = performanceIndex;
        this.isCertified = false;
    }

    // Method to set the salary based on the new salary and performance index
    public void setSalary(double newSalary, int newPerformanceIndex) {
        salary = newSalary;
        performanceIndex = newPerformanceIndex;

        // Check conditions for salary approval
        if (newPerformanceIndex > 5 && getWorkingHours() > 20) {
            double appraisal;

            // Determine appraisal based on performance index
            if (5 < newPerformanceIndex && newPerformanceIndex <= 7) {
                appraisal = 0.05;
            } else if (7 < newPerformanceIndex && newPerformanceIndex <= 9) {
                appraisal = 0.1;
            } else {
                appraisal = 0.2;
            }

            // Apply appraisal to the salary and mark as certified
            this.salary += this.salary * appraisal;
            isCertified = true;
            performanceIndex = newPerformanceIndex;
        } else {
            System.out.println("Salary cannot be approved yet.");
        }
    }

    // Method to remove a tutor if not certified
    public void removeTutor() {
        if (!isCertified) {
            // Reset attributes if the tutor is not certified
            salary = 0;
            specialization = "";
            academicQualifications = "";
            performanceIndex = 0;
        }
    }

    // Method to display information about the tutor
    public void display() {
        // Call the display method of the superclass (Teacher) to display common information
        super.display();

        // Display additional information specific to the Tutor class
        if (!isCertified) {
            System.out.println("Salary: Not certified yet");
        } else {
            System.out.println("Salary: " + salary);
            System.out.println("Specialization: " + specialization);
            System.out.println("Academic Qualifications: " + academicQualifications);
            System.out.println("Performance Index: " + performanceIndex);
        }
    }

    // Accessor methods

    public double getSalary() {
        return salary;
    }

    public String getSpecialization() {
        return specialization;
    }

    public String getAcademicQualifications() {
        return academicQualifications;
    }

    public int getPerformanceIndex() {
        return performanceIndex;
    }

    public boolean isCertified() {
        return isCertified;
    }
}


